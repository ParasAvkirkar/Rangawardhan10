package adapter;

/**
 * Created by akashj on 31/08/2015.
 */

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;

import com.etsy.android.grid.util.DynamicHeightImageView;
import com.example.akashj.rangawardhan10.R;

import java.util.ArrayList;

public class SampleAdapter extends ArrayAdapter<Integer> {

    public SampleAdapter(Context context, ArrayList<Integer> objects) {
        super(context, R.layout.ranga_grid_item, objects);
    }

    private static class ViewHolder {
        DynamicHeightImageView imageView;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        if (convertView == null) {
            holder = new ViewHolder();
            convertView = LayoutInflater.from(parent.getContext()).inflate(R.layout.ranga_grid_item, parent, false);
            holder.imageView = (DynamicHeightImageView) convertView.findViewById(R.id.ranga_grid_spons);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        holder.imageView.setImageResource(getItem(position));
        return convertView;
    }
}
