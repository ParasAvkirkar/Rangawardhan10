package activity;

/**
 * Created by akashj on 10/09/2015.
 */
public class DeveloperInfo {
    String Name, email;
    int imageId;

    public DeveloperInfo(String name, String email, int imageId) {
        Name = name;
        this.email = email;
        this.imageId = imageId;
    }

    public String getName() {
        return Name;
    }

    public String getEmail() {
        return email;
    }

    public int getImageId() {
        return imageId;
    }
}